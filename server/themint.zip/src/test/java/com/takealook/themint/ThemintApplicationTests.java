package com.takealook.themint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThemintApplicationTests {

    @Test
    void contextLoads() {
    }

}
