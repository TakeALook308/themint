package com.takealook.themint;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThemintApplication {

    public static void main(String[] args) {
        SpringApplication.run(ThemintApplication.class, args);
    }

}
