CREATE DATABASE  IF NOT EXISTS `themint_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `themint_db`;
-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7a308.p.ssafy.io    Database: themint_db
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auction`
--

DROP TABLE IF EXISTS `auction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auction` (
  `seq` bigint NOT NULL AUTO_INCREMENT,
  `member_seq` bigint NOT NULL,
  `title` varchar(60) NOT NULL,
  `content` varchar(2000) NOT NULL,
  `category_seq` bigint NOT NULL,
  `start_time` datetime DEFAULT NULL,
  `hash` varchar(255) DEFAULT NULL,
  `status` int NOT NULL,
  `interest` int NOT NULL,
  PRIMARY KEY (`seq`),
  KEY `auction_memberseq_fk_member_seq_idx` (`member_seq`),
  CONSTRAINT `auction_memberseq_fk_member_seq` FOREIGN KEY (`member_seq`) REFERENCES `member` (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction`
--

LOCK TABLES `auction` WRITE;
/*!40000 ALTER TABLE `auction` DISABLE KEYS */;
INSERT INTO `auction` VALUES (1,3,'여성 의류 (바지) 팔아요','크림색 일자바지랑 찢어진 청바지 팔아요',1,'2022-08-19 17:00:00','c06d02e8a6fad796cbfff7bfa6548cb1',0,0),(3,1,'스투시 반팔 두장!','스투시 반팔 두장 팝니다 상태 좋아요!',1,'2022-08-20 00:00:00','02f69a3aa4fc360b9d08ada8df002ea3',0,2),(4,1,'나이키 바람막이 팝니다!','나이키 바람막이 팝니다 아주이뻐요',1,'2022-08-19 12:00:00','7806e4b00d8e94efb025c558ddda2977',1,2),(5,2,'맥 립스틱 두개 팔아요','저한테는 안 어울리는 색이라 팝니당',2,'2022-08-19 16:30:00','9a1b084685775a445b3e49775996f7a2',0,0),(6,5,'asus노트북 팝니다!','asus 노트북 성능 좋아요!',8,'2022-08-17 12:00:00','1c4a7fa6ac4326fb07c487d30658e881',2,0),(7,5,'노트북 파우치 팝니다!','귀여운 호랑이 노트북 파우치 팔아요!',12,'2022-08-17 14:00:00','074ecd11a6d00a25e0dd51b9a3eaa9c1',2,0),(8,3,'옷들 팔아요','경매 라이브에서 보여드릴게요',1,'2022-08-19 19:30:00','0e737472df63d239ab91829b608d2099',0,0),(9,2,'냉정과 열정사이 책 세트 팝니다!','정말 재밌어요.. 강추드립니다',11,'2022-08-17 15:00:00','927439293363a402e09d80d2c09f6004',2,1),(10,2,'프라이탁 가방','귀여운 인형도 같이드려요',1,'2022-08-17 17:00:00','315a7ee0a2b9dcbd6a2e5f50b2b697eb',2,1),(11,5,'에어팟 프로 + 귀여운 케이스 팔아요','상태좋아요~!',8,'2022-08-20 15:00:00','8a2bd07d2aac755f2b26c4e19ebab9d6',0,0),(12,4,'적축 기계식 키보드 팝니다','키캡 완전 귀여워요!',8,'2022-08-18 14:00:00','220840c73418322653e25bdc9171cce6',2,1),(13,4,'피아노 팝니다!','소리 좋아요!!',8,'2022-08-19 15:00:00','579ad571214b147ee48804bfaae53422',2,0),(14,4,'카메라 팝니다!','아주 귀여워용!',8,'2022-08-16 12:00:00','e4081c5ead9f586b32f7b6268f4dddf4',2,0),(15,4,'스누피 컵 팝니다','한번도 안썻어요!',5,'2022-08-20 14:30:00','bd7406c76c211fd6558f966bc56061b2',2,0),(16,4,'인체공학 마우스 팝니다','아주 편한 마우스입니다.',1,'2022-08-18 18:30:00','7617d315cf57d3a7c1f20787afe31905',2,0),(17,1,'심플한 시계','잘 작동해요',7,'2022-08-20 16:00:00','c0424692455ccc703846af60335c84f3',0,0),(18,6,'닌텐도 스위치 팔아요','닌텐도 스위치 민트급!',8,'2022-08-19 12:00:00','8b1a5e513ab4fdff21258bfc5f857697',1,1),(19,1,'컴퓨터 전공 책 팝니다','엄청싸게팔게요!!',11,'2022-08-20 12:00:00','5d6a52217eea6b570353f80b854e728e',0,0),(20,3,'인형 여러개 팔아요','인형뽑기 너무 많이해서 처분합니당',12,'2022-08-19 12:00:00','cf34ccbe24aa024b6912da6cba2914c0',1,1),(21,4,'귀여운 춘식이','두마리 분양보내요',7,'2022-08-19 15:00:00','e19db71fdaa5ea89ab5d935498dc8508',2,0),(22,4,'브라운 가습기','너무너무 귀여워용',12,'2022-08-18 15:00:00','1247e62d281be094afdaccc8a321c460',2,0),(23,4,'다양한 제품 팝니다','마우스패드 급처!',8,'2022-08-17 16:00:00','ee0026e4527331fba340a674fe907efd',2,0),(24,4,'눈마사지기 급처','눈마사지기 진짜싸게 급처합니다',8,'2022-08-16 20:00:00','6af73b5575554b2893f4332367e3f47e',2,0),(25,4,'닌텐도 스위치 별의 커비','닌텐도 스위치 별의 커비 게임 팔아요!',12,'2022-08-15 16:00:00','91ce898802d639fd1701d03dcf15a307',2,0),(26,4,'닌텐도 스위치 별의 커비','닌텐도 스위치 별의 커비 게임 팝니다!',12,'2022-08-17 22:00:00','269ae3c00af4e3247a1f695c31cd3f87',2,0),(28,1,'갤럭시 탭 S8 울트라 팝니다!','단순 미개봉 새제품이에요!',8,'2022-08-21 14:30:00','ba42fdad95d1112b9fa7cdef1cb6d2b3',0,0),(29,5,'갤럭시 Z플립2 팝니다','색감이 아주 이뻐요!',8,'2022-08-20 12:30:00','39e9bc94826b8e830e57cdf863cc722e',1,0),(31,3,'갤럭시 버즈 팝니다','상태 좋고 음질 좋아요!',8,'2022-08-20 19:30:00','042f4be57d3d0891389e44bcb8cf2328',0,0),(32,2,'갤럭시 휴대폰 여러개 팔아요','다양한 갤럭시 휴대폰 팝니다!\n성능 진짜 정말좋아요',8,'2022-08-20 23:20:00','83a628e9d7d13ad0c562be70d05cc301',0,0),(33,4,'갤럭시 탭 S7 팝니다','구매하시면 펜도 같이 드려요!!',8,'2022-08-22 14:00:00','b1c567de0972fa4dec19a8891ce7e678',2,0),(36,4,'곰인형','곰인형 팔아요',7,'2022-08-22 17:00:00','c8230a9369557f1fce98c5338c19b5b0',2,0),(37,4,'wells 공기청정기 ','저렴하게 내놓습니다',8,'2022-08-22 19:00:00','cb2423fb95757b0536d392b92853adb8',2,0),(38,4,'향수','향이 되게 좋아요',2,'2022-08-17 18:00:00','b11e51c33101b03cbd6183e5b997c4ed',2,0),(39,9,'닌텐도 스위치 포켓몬 아르세우스','포켓몬 아르세우스 게임 입니다!',12,'2022-08-16 19:10:00','d844245db6b520db1654762338e8531d',2,0),(40,9,'푸시업바 팝니다','푸시업바 싸게 팔아요!',9,'2022-08-16 18:00:00','9e2b05c3f2f40411274f1c65fe4d0254',2,0),(41,2,'애옹이 파우치','엄청귀여워요!',6,'2022-08-16 19:30:00','1900ddbe490f46e7e9854fd12e3b22f4',2,0),(42,2,'이솝핸드크림','이솝핸드크림 팝니다!',2,'2022-08-14 17:00:00','e3ce90b5d66a29582f0e9b8a20bb25da',2,0),(43,3,'양키캔들 체리향 팝니다','향이 정말 좋아요!',7,'2022-08-18 19:30:00','d56d1c6cf3e866d96ed76f64e343fb6e',2,0),(44,5,'해밀턴 손목시계 팝니다','진짜 이뻐요!',1,'2022-08-18 18:30:00','359f7294ff3fa77f82c061acb253f106',2,0);
/*!40000 ALTER TABLE `auction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction_image`
--

DROP TABLE IF EXISTS `auction_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auction_image` (
  `seq` bigint NOT NULL AUTO_INCREMENT,
  `auction_seq` bigint NOT NULL,
  `image_url` varchar(500) NOT NULL,
  PRIMARY KEY (`seq`),
  KEY `auctionimage_auctionseq_fk_auction_seq_idx` (`auction_seq`),
  CONSTRAINT `auctionimage_auctionseq_fk_auction_seq` FOREIGN KEY (`auction_seq`) REFERENCES `auction` (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction_image`
--

LOCK TABLES `auction_image` WRITE;
/*!40000 ALTER TABLE `auction_image` DISABLE KEYS */;
INSERT INTO `auction_image` VALUES (2,1,'/product/c06d02e8a6fad796cbfff7bfa6548cb1/279b4008-0d4d-4af3-a119-b9f3b9612215.jpg'),(3,1,'/product/c06d02e8a6fad796cbfff7bfa6548cb1/62fe676d-942e-429a-9385-7e2c7882bc9b.jpg'),(5,3,'/product/02f69a3aa4fc360b9d08ada8df002ea3/aa37b428-1672-4917-be18-ac4968327229.jpg'),(6,4,'/product/7806e4b00d8e94efb025c558ddda2977/7864d849-a635-4841-b064-e29d8ed05084.jpg'),(7,5,'/product/9a1b084685775a445b3e49775996f7a2/731877a3-2797-4891-85be-d30cf99a2a94.jfif'),(8,5,'/product/9a1b084685775a445b3e49775996f7a2/be748b98-ccc9-4a89-ad79-6f4dc5dc38e1.jpg'),(9,6,'/product/1c4a7fa6ac4326fb07c487d30658e881/6a094e1a-50e2-41f1-b9bf-22d7a4b55ec6.jpg'),(10,7,'/product/074ecd11a6d00a25e0dd51b9a3eaa9c1/e93beb08-b2bc-4986-8803-00e8296c4931.jpg'),(11,8,'/product/basic1.png'),(12,9,'/product/927439293363a402e09d80d2c09f6004/aa72daa6-c861-4321-988a-564634df9321.jpg'),(13,10,'/product/315a7ee0a2b9dcbd6a2e5f50b2b697eb/2d85f828-98c8-45ac-a91e-8e168c7ddbe3.jpg'),(14,11,'/product/8a2bd07d2aac755f2b26c4e19ebab9d6/d73b5735-d8d4-4154-88ce-e5c335180648.jpg'),(15,12,'/product/220840c73418322653e25bdc9171cce6/9c59d7a6-11d2-460b-bf78-64cd0eb10928.jpg'),(16,13,'/product/579ad571214b147ee48804bfaae53422/2b041ae3-e013-449d-a1fd-f3f13c2648c8.jpg'),(17,14,'/product/e4081c5ead9f586b32f7b6268f4dddf4/e05419ce-5afe-4256-8afc-80b5837f95ad.jpg'),(18,15,'/product/bd7406c76c211fd6558f966bc56061b2/30906045-4d10-47c3-9870-80399afc0a9c.jpg'),(19,16,'/product/7617d315cf57d3a7c1f20787afe31905/72a3c031-ed46-40bc-b744-d3005aa14be0.jpg'),(20,17,'/product/c0424692455ccc703846af60335c84f3/48fdd5ef-8106-43e1-a9c5-1fb4fdba3b6e.jpg'),(21,18,'/product/8b1a5e513ab4fdff21258bfc5f857697/0dc93414-035d-448c-9659-3863b71f4958.jpg'),(22,19,'/product/5d6a52217eea6b570353f80b854e728e/ca71496b-a8a3-45c1-96ec-d9b9e10ced26.jpg'),(23,20,'/product/cf34ccbe24aa024b6912da6cba2914c0/d1edffe7-3de4-4757-8f2a-38094a554478.jpg'),(24,21,'/product/e19db71fdaa5ea89ab5d935498dc8508/c9af5979-67ed-4d75-8ef1-25b112f1fa27.jpg'),(25,22,'/product/1247e62d281be094afdaccc8a321c460/7934f23a-7a88-404f-8901-44948d3dec95.jpg'),(26,23,'/product/ee0026e4527331fba340a674fe907efd/0af282b6-4123-4b45-a514-9783d0e4aa02.jpg'),(29,24,'/product/6af73b5575554b2893f4332367e3f47e/8bd1f427-e59d-4dfc-b099-2526646394dc.jpg'),(30,25,'/product/91ce898802d639fd1701d03dcf15a307/9c0627dd-a0d7-4e61-9531-eb2309d5dcdb.jpg'),(31,26,'/product/269ae3c00af4e3247a1f695c31cd3f87/e7ec3651-3ab3-45fe-a47a-b8556b9d41d9.jpg'),(33,28,'/product/ba42fdad95d1112b9fa7cdef1cb6d2b3/4c5016c6-7f05-4eae-b692-6753b84f9898.jpg'),(34,29,'/product/39e9bc94826b8e830e57cdf863cc722e/1e53041f-69f3-4dd0-b813-93774f8d6d6f.jpg'),(36,31,'/product/042f4be57d3d0891389e44bcb8cf2328/5954e09a-48de-4b89-b64f-163f3a5b1439.jpg'),(37,32,'/product/83a628e9d7d13ad0c562be70d05cc301/53dc4927-2ef2-48c9-80ad-9744e98307b7.PNG'),(38,33,'/product/b1c567de0972fa4dec19a8891ce7e678/9e92a003-5268-4d2e-b015-5f859887d809.jpg'),(41,36,'/product/c8230a9369557f1fce98c5338c19b5b0/d15b0215-381a-4120-85f9-51121a4fa9a8.jpg'),(42,37,'/product/cb2423fb95757b0536d392b92853adb8/61817c94-ff7a-42f7-a160-fe2de18d6f41.jpg'),(43,38,'/product/b11e51c33101b03cbd6183e5b997c4ed/0b9248e1-e072-49a2-9289-a08ffb6aeed4.jpg'),(44,39,'/product/d844245db6b520db1654762338e8531d/8750eac2-5b2c-4dd1-9215-ce228b9ce17b.jpg'),(45,40,'/product/9e2b05c3f2f40411274f1c65fe4d0254/91073d87-0a81-4910-8f46-19751494027b.jpg'),(46,41,'/product/1900ddbe490f46e7e9854fd12e3b22f4/064a54d9-02cf-4aef-ada7-78743452bd55.jpg'),(47,42,'/product/e3ce90b5d66a29582f0e9b8a20bb25da/344a8169-ca87-4d1f-be3d-5eaaeb699c8b.jpg'),(48,43,'/product/d56d1c6cf3e866d96ed76f64e343fb6e/20d87b65-98c0-4d7d-8460-fea008ad8139.jpg'),(49,44,'/product/359f7294ff3fa77f82c061acb253f106/bad33c3d-e096-4531-a555-8b7d01c38262.jpg');
/*!40000 ALTER TABLE `auction_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank`
--

DROP TABLE IF EXISTS `bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bank` (
  `bank_code` bigint NOT NULL,
  `bank_name` varchar(30) NOT NULL,
  PRIMARY KEY (`bank_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank`
--

LOCK TABLES `bank` WRITE;
/*!40000 ALTER TABLE `bank` DISABLE KEYS */;
INSERT INTO `bank` VALUES (2,'KDB산업은행'),(3,'IBK기업은행'),(4,'KB국민은행'),(7,'수협은행'),(11,'NH농협은행'),(12,'농협중앙회(단위농축협)'),(20,'우리은행'),(23,'SC제일은행'),(27,'한국씨티은행'),(31,'대구은행'),(32,'부산은행'),(34,'광주은행'),(35,'제주은행'),(37,'전북은행'),(39,'경남은행'),(45,'새마을금고중앙회'),(48,'신협중앙회'),(50,'저축은행중앙회'),(64,'산림조합중앙회'),(71,'우체국'),(81,'하나은행'),(88,'신한은행'),(89,'케이뱅크'),(90,'카카오뱅크'),(92,'토스뱅크'),(218,'KB증권'),(238,'미래에셋대우'),(240,'삼성증권'),(243,'한국투자증권'),(247,'NH투자증권'),(261,'교보증권'),(262,'하이투자증권'),(263,'현대차증권'),(264,'키움증권'),(265,'이베스트투자증권'),(266,'SK증권'),(267,'대신증권'),(269,'한화투자증권'),(278,'신한금융투자'),(279,'DB금융투자'),(280,'유진투자증권'),(287,'메리츠증권');
/*!40000 ALTER TABLE `bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `base_image`
--

DROP TABLE IF EXISTS `base_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `base_image` (
  `seq` bigint NOT NULL AUTO_INCREMENT,
  `image_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `base_image`
--

LOCK TABLES `base_image` WRITE;
/*!40000 ALTER TABLE `base_image` DISABLE KEYS */;
INSERT INTO `base_image` VALUES (1,'/product/basic1.png');
/*!40000 ALTER TABLE `base_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bid_message`
--

DROP TABLE IF EXISTS `bid_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bid_message` (
  `seq` bigint NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `member_seq` bigint DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `price` int NOT NULL,
  `room_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bid_message`
--

LOCK TABLES `bid_message` WRITE;
/*!40000 ALTER TABLE `bid_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `bid_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `seq` bigint NOT NULL AUTO_INCREMENT,
  `category_name` varchar(20) NOT NULL,
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'패션의류/잡화'),(2,'뷰티'),(3,'출산/유아동'),(4,'식품'),(5,'주방용품'),(6,'생활용품'),(7,'홈인테리어'),(8,'가전/디지털'),(9,'스포츠/레저'),(10,'자동차용품'),(11,'도서/음반/DVD'),(12,'완구/취미'),(13,'문구/오피스'),(14,'반려동물용품'),(15,'헬스/건강식품');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_message`
--

DROP TABLE IF EXISTS `chat_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_message` (
  `seq` bigint NOT NULL AUTO_INCREMENT,
  `room_id` varchar(250) NOT NULL,
  `message` varchar(500) NOT NULL,
  `member_seq` bigint NOT NULL,
  `nickname` varchar(20) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `type` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`seq`),
  KEY `chatmessage_roomid_fk_chatroom_roomid_idx` (`room_id`),
  KEY `chatmessage_memeberseq_fk_member_seq_idx` (`member_seq`),
  CONSTRAINT `chatmessage_memeberseq_fk_member_seq` FOREIGN KEY (`member_seq`) REFERENCES `member` (`seq`),
  CONSTRAINT `chatmessage_roomid_fk_chatroom_roomid` FOREIGN KEY (`room_id`) REFERENCES `chat_room` (`room_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_message`
--

LOCK TABLES `chat_message` WRITE;
/*!40000 ALTER TABLE `chat_message` DISABLE KEYS */;
INSERT INTO `chat_message` VALUES (1,'1to3','안녕하세요',3,'comet308','2022-08-19 01:17:07',2),(2,'1to3','잘 지내시나요?',3,'comet308','2022-08-19 01:17:10',2),(3,'3to4','안녕하세요',3,'comet308','2022-08-19 01:17:22',2),(4,'3to4','저번에 보내주신 물건 잘 받았어요',3,'comet308','2022-08-19 01:17:46',2),(5,'3to4','화면에서 보던대로 아주 이쁘네요!',3,'comet308','2022-08-19 01:17:55',2),(6,'3to4','감사해요',3,'comet308','2022-08-19 01:17:58',2),(7,'3to4','애착 물건이에요! 잘사용해주세요 ^8^',4,'lucas308','2022-08-19 01:25:19',2),(8,'0d7b3065165fba59817ab310d5d64c4c','eric308님이 입장하셨습니다.',5,'eric308','2022-08-19 03:08:03',0),(9,'0d7b3065165fba59817ab310d5d64c4c','mino308님이 입장하셨습니다.',1,'mino308','2022-08-19 03:08:52',0),(10,'0d7b3065165fba59817ab310d5d64c4c','comet308님이 입장하셨습니다.',3,'comet308','2022-08-19 03:09:16',0),(11,'0d7b3065165fba59817ab310d5d64c4c','lucas308님이 입장하셨습니다.',4,'lucas308','2022-08-19 03:14:43',0),(12,'0d7b3065165fba59817ab310d5d64c4c','안녕하세요~',3,'comet308','2022-08-19 03:14:51',1),(13,'0d7b3065165fba59817ab310d5d64c4c','안녕하세요~',4,'lucas308','2022-08-19 03:14:55',1),(14,'0d7b3065165fba59817ab310d5d64c4c','와 이뻐용',1,'mino308','2022-08-19 03:14:56',1),(15,'0d7b3065165fba59817ab310d5d64c4c','카메라 한번 켜주세요!',1,'mino308','2022-08-19 03:14:59',1),(16,'0d7b3065165fba59817ab310d5d64c4c','s펜은 잘 되나요?',3,'comet308','2022-08-19 03:15:07',1),(17,'0d7b3065165fba59817ab310d5d64c4c','앗',3,'comet308','2022-08-19 03:15:24',1),(18,'0d7b3065165fba59817ab310d5d64c4c','허허',1,'mino308','2022-08-19 03:15:27',1),(19,'0d7b3065165fba59817ab310d5d64c4c','못 이기겠네요ㅜㅜ',3,'comet308','2022-08-19 03:15:27',1),(20,'0d7b3065165fba59817ab310d5d64c4c','축하드려요!',1,'mino308','2022-08-19 03:15:43',1),(21,'0d7b3065165fba59817ab310d5d64c4c','축하드려용',3,'comet308','2022-08-19 03:15:55',1),(22,'0d7b3065165fba59817ab310d5d64c4c','부럽네요ㅠㅠ',3,'comet308','2022-08-19 03:15:57',1),(23,'4to5','안녕하세요',5,'eric308','2022-08-19 03:18:41',2),(24,'0d7b3065165fba59817ab310d5d64c4c','eric308님이 입장하셨습니다.',5,'eric308','2022-08-19 03:18:52',0),(25,'0d7b3065165fba59817ab310d5d64c4c','ㅇㅇ',1,'mino308','2022-08-19 03:19:44',1),(26,'0d7b3065165fba59817ab310d5d64c4c','lucas308님이 입장하셨습니다.',4,'lucas308','2022-08-19 03:23:52',0),(27,'0d7b3065165fba59817ab310d5d64c4c','안녕하세요~!!',1,'mino308','2022-08-19 03:23:54',1),(28,'0d7b3065165fba59817ab310d5d64c4c','내가 사야징',3,'comet308','2022-08-19 03:24:03',1),(29,'0d7b3065165fba59817ab310d5d64c4c','제껍니다',4,'lucas308','2022-08-19 03:24:06',1),(30,'0d7b3065165fba59817ab310d5d64c4c','휴대폰 카메라 한번 켜주세요!!',1,'mino308','2022-08-19 03:24:07',1),(31,'0d7b3065165fba59817ab310d5d64c4c','S펜 잘 작동하나요?',3,'comet308','2022-08-19 03:24:12',1),(32,'0d7b3065165fba59817ab310d5d64c4c','너무 갖고싶다',1,'mino308','2022-08-19 03:24:23',1),(33,'0d7b3065165fba59817ab310d5d64c4c','헉',1,'mino308','2022-08-19 03:24:37',1),(34,'0d7b3065165fba59817ab310d5d64c4c','25만원..',1,'mino308','2022-08-19 03:24:38',1),(35,'0d7b3065165fba59817ab310d5d64c4c','헐랭',3,'comet308','2022-08-19 03:24:51',1),(36,'0d7b3065165fba59817ab310d5d64c4c','ㅜㅜㅜ',3,'comet308','2022-08-19 03:24:53',1),(37,'0d7b3065165fba59817ab310d5d64c4c','축하드립니다',1,'mino308','2022-08-19 03:24:56',1),(38,'4to5','입금확인했습니다~ 빨리보내드리겠습니다.',5,'eric308','2022-08-19 03:25:22',2),(39,'4to5','빨리보내주세요~',4,'lucas308','2022-08-19 03:25:32',2),(40,'1to4','좋은 거래 감사합니다~!',1,'mino308','2022-08-19 03:27:32',2),(41,'0d7b3065165fba59817ab310d5d64c4c','eric308님이 입장하셨습니다.',5,'eric308','2022-08-19 03:28:07',0),(42,'0d7b3065165fba59817ab310d5d64c4c','lucas308님이 입장하셨습니다.',4,'lucas308','2022-08-19 03:28:13',0),(43,'0d7b3065165fba59817ab310d5d64c4c','꺼써용',4,'lucas308','2022-08-19 03:28:30',1),(44,'0d7b3065165fba59817ab310d5d64c4c','어디서 하울링은',4,'lucas308','2022-08-19 03:28:38',1),(45,'0d7b3065165fba59817ab310d5d64c4c','나는데',4,'lucas308','2022-08-19 03:28:41',1),(46,'0d7b3065165fba59817ab310d5d64c4c','ㅇㅇ',4,'lucas308','2022-08-19 03:28:47',1),(53,'bffb2abf9585edd5540482635f187116','eric308님이 입장하셨습니다.',5,'eric308','2022-08-19 03:35:59',0),(54,'bffb2abf9585edd5540482635f187116','mino308님이 입장하셨습니다.',1,'mino308','2022-08-19 03:36:04',0),(55,'bffb2abf9585edd5540482635f187116','ㅎㅇ',1,'mino308','2022-08-19 03:36:31',1),(56,'bffb2abf9585edd5540482635f187116','ㅎㅇㅎㅇ',3,'comet308','2022-08-19 03:36:35',1),(57,'bffb2abf9585edd5540482635f187116','lucas308님이 입장하셨습니다.',4,'lucas308','2022-08-19 03:36:57',0),(58,'bffb2abf9585edd5540482635f187116','안녕하세요~',1,'mino308','2022-08-19 03:37:00',1),(59,'bffb2abf9585edd5540482635f187116','안녕하세요',3,'comet308','2022-08-19 03:37:02',1),(60,'bffb2abf9585edd5540482635f187116','안녕하세요~~~',4,'lucas308','2022-08-19 03:37:06',1),(61,'bffb2abf9585edd5540482635f187116','색 이쁘네용',3,'comet308','2022-08-19 03:37:11',1),(62,'bffb2abf9585edd5540482635f187116','카메라는 잘 작동하나요??',1,'mino308','2022-08-19 03:37:11',1),(63,'bffb2abf9585edd5540482635f187116','예쁘다...',4,'lucas308','2022-08-19 03:37:14',1),(64,'bffb2abf9585edd5540482635f187116','S펜 잘 되나요?',3,'comet308','2022-08-19 03:37:16',1),(65,'bffb2abf9585edd5540482635f187116','이건.. 사야해..',1,'mino308','2022-08-19 03:37:23',1),(66,'bffb2abf9585edd5540482635f187116','헐 25만원..',1,'mino308','2022-08-19 03:37:41',1),(67,'bffb2abf9585edd5540482635f187116','엇',3,'comet308','2022-08-19 03:37:41',1),(68,'bffb2abf9585edd5540482635f187116','큰손이시다',3,'comet308','2022-08-19 03:37:43',1),(69,'bffb2abf9585edd5540482635f187116','이건 제껀거 같아요~~',4,'lucas308','2022-08-19 03:37:47',1),(70,'bffb2abf9585edd5540482635f187116','호호호호',4,'lucas308','2022-08-19 03:37:50',1),(71,'bffb2abf9585edd5540482635f187116','전 학생이라 돈이 없어요ㅠㅠㅠ',3,'comet308','2022-08-19 03:37:51',1),(72,'bffb2abf9585edd5540482635f187116','제껍니다',4,'lucas308','2022-08-19 03:37:53',1),(73,'bffb2abf9585edd5540482635f187116','ㅠㅠ 잘쓰세요..',1,'mino308','2022-08-19 03:37:53',1),(74,'bffb2abf9585edd5540482635f187116','축하드려용',3,'comet308','2022-08-19 03:38:13',1),(75,'4to5','입금확인했습니다~ 빨리 보내드릴게요^^',5,'eric308','2022-08-19 03:38:37',2),(76,'4to5','빨리보주세ㅐ요~~~',4,'lucas308','2022-08-19 03:39:11',2),(77,'4to5','잘쓸게요~~~호호',4,'lucas308','2022-08-19 03:43:29',2),(78,'2to4','포장 너무 잘해주셔서 감사합니다 ㅎㅎ',2,'애용이','2022-08-19 03:44:24',2),(79,'4to9','배송 빨리 부탁드려용~',9,'갤럭시맨','2022-08-19 03:46:26',2);
/*!40000 ALTER TABLE `chat_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room`
--

DROP TABLE IF EXISTS `chat_room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room` (
  `room_id` varchar(250) NOT NULL,
  `type` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`room_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room`
--

LOCK TABLES `chat_room` WRITE;
/*!40000 ALTER TABLE `chat_room` DISABLE KEYS */;
INSERT INTO `chat_room` VALUES ('0d7b3065165fba59817ab310d5d64c4c',0),('1',0),('1to3',1),('1to4',1),('2to4',1),('3to4',1),('4to5',1),('4to9',1),('bffb2abf9585edd5540482635f187116',0),('e19db71fdaa5ea89ab5d935498dc8508',0);
/*!40000 ALTER TABLE `chat_room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_member`
--

DROP TABLE IF EXISTS `chat_room_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_member` (
  `seq` bigint NOT NULL AUTO_INCREMENT,
  `room_id` varchar(250) DEFAULT NULL,
  `member_seq` bigint DEFAULT NULL,
  PRIMARY KEY (`seq`),
  KEY `chatroommember_roomid_fk_chatroom_roomid_idx` (`room_id`),
  KEY `chatroommember_memberseq_fk_member_seq_idx` (`member_seq`),
  CONSTRAINT `chatroommember_memberseq_fk_member_seq` FOREIGN KEY (`member_seq`) REFERENCES `member` (`seq`),
  CONSTRAINT `chatroommember_roomid_fk_chatroom_roomid` FOREIGN KEY (`room_id`) REFERENCES `chat_room` (`room_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_member`
--

LOCK TABLES `chat_room_member` WRITE;
/*!40000 ALTER TABLE `chat_room_member` DISABLE KEYS */;
INSERT INTO `chat_room_member` VALUES (1,'1to3',3),(2,'1to3',1),(3,'3to4',3),(4,'3to4',4),(5,'4to5',5),(6,'4to5',4),(7,'1to4',1),(8,'1to4',4),(9,'2to4',2),(10,'2to4',4),(11,'4to9',9),(12,'4to9',4);
/*!40000 ALTER TABLE `chat_room_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `history` (
  `seq` bigint NOT NULL AUTO_INCREMENT,
  `member_seq` bigint NOT NULL,
  `product_seq` bigint NOT NULL,
  `sales_purchase` tinyint NOT NULL,
  `date` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`seq`),
  KEY `saleshistory_memberseq_fk_member_seq_idx` (`member_seq`),
  KEY `saleshistory_productseq_fk_product_seq_idx` (`product_seq`),
  CONSTRAINT `history_memberseq_fk_member_seq` FOREIGN KEY (`member_seq`) REFERENCES `member` (`seq`),
  CONSTRAINT `history_productseq_fk_product_seq` FOREIGN KEY (`product_seq`) REFERENCES `product` (`seq`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history`
--

LOCK TABLES `history` WRITE;
/*!40000 ALTER TABLE `history` DISABLE KEYS */;
INSERT INTO `history` VALUES (2,3,2,0,'2022-08-19 01:15:43'),(3,3,3,0,'2022-08-19 01:15:43'),(5,1,5,0,'2022-08-19 01:18:29'),(6,1,6,0,'2022-08-19 01:18:29'),(7,1,7,0,'2022-08-19 01:19:58'),(8,3,8,0,'2022-08-19 01:20:22'),(9,3,9,0,'2022-08-19 01:20:22'),(10,5,10,0,'2022-08-19 01:29:28'),(11,5,11,0,'2022-08-19 01:30:22'),(12,3,12,0,'2022-08-19 01:31:10'),(13,2,13,0,'2022-08-19 01:31:37'),(14,2,14,0,'2022-08-19 01:32:29'),(15,5,15,0,'2022-08-19 01:34:00'),(16,4,16,0,'2022-08-19 01:37:34'),(17,4,17,0,'2022-08-19 01:38:29'),(18,4,18,0,'2022-08-19 01:42:08'),(19,4,19,0,'2022-08-19 01:43:11'),(20,4,20,0,'2022-08-19 01:43:47'),(21,1,21,0,'2022-08-19 01:49:16'),(22,1,22,0,'2022-08-19 01:50:30'),(23,1,23,0,'2022-08-19 01:51:50'),(24,1,24,0,'2022-08-19 01:51:50'),(25,1,25,0,'2022-08-19 01:51:50'),(26,3,26,0,'2022-08-19 01:52:00'),(27,3,27,0,'2022-08-19 01:52:00'),(28,3,28,0,'2022-08-19 01:52:00'),(29,3,29,0,'2022-08-19 01:52:00'),(30,3,30,0,'2022-08-19 01:52:00'),(31,3,31,0,'2022-08-19 01:52:00'),(32,3,32,0,'2022-08-19 01:52:00'),(33,4,33,0,'2022-08-19 01:53:21'),(34,4,34,0,'2022-08-19 01:53:21'),(35,4,35,0,'2022-08-19 02:11:56'),(36,4,36,0,'2022-08-19 02:14:51'),(39,4,39,0,'2022-08-19 02:17:46'),(40,4,40,0,'2022-08-19 02:19:28'),(41,1,41,0,'2022-08-19 02:30:59'),(42,5,42,0,'2022-08-19 02:32:53'),(43,3,43,0,'2022-08-19 02:35:16'),(44,2,44,0,'2022-08-19 02:43:22'),(45,2,45,0,'2022-08-19 02:43:22'),(46,2,46,0,'2022-08-19 02:43:22'),(47,4,47,0,'2022-08-19 02:45:41'),(55,4,53,0,'2022-08-19 04:00:07'),(56,4,54,0,'2022-08-19 04:00:45'),(57,4,55,0,'2022-08-19 04:01:32'),(62,9,56,0,'2022-08-19 04:32:12'),(63,9,57,0,'2022-08-19 04:33:12'),(64,2,58,0,'2022-08-19 04:33:54'),(65,2,59,0,'2022-08-19 04:34:29'),(66,3,60,0,'2022-08-19 04:35:53'),(67,5,61,0,'2022-08-19 04:36:53'),(75,4,13,1,'2022-08-19 05:44:12'),(76,4,14,1,'2022-08-19 05:44:39'),(77,4,10,1,'2022-08-19 05:45:19'),(78,4,11,1,'2022-08-19 05:45:25'),(79,4,26,1,'2022-08-19 05:46:58'),(80,4,57,1,'2022-08-19 05:56:17'),(81,4,58,1,'2022-08-19 05:56:25'),(82,4,59,1,'2022-08-19 05:56:33'),(83,4,60,1,'2022-08-19 05:56:40'),(84,4,61,1,'2022-08-19 05:56:47'),(85,1,18,1,'2022-08-19 06:17:06'),(86,1,36,1,'2022-08-19 06:17:39'),(87,1,39,1,'2022-08-19 06:17:45'),(88,2,16,1,'2022-08-19 06:19:28'),(89,5,17,1,'2022-08-19 06:20:27'),(90,5,19,1,'2022-08-19 06:20:39'),(91,5,20,1,'2022-08-19 06:20:49'),(92,3,33,1,'2022-08-19 06:21:04'),(93,3,34,1,'2022-08-19 06:21:06'),(94,3,35,1,'2022-08-19 06:21:22'),(95,2,40,1,'2022-08-19 06:21:40'),(96,2,55,1,'2022-08-19 06:21:53');
/*!40000 ALTER TABLE `history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interest_auction`
--

DROP TABLE IF EXISTS `interest_auction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interest_auction` (
  `seq` bigint NOT NULL AUTO_INCREMENT,
  `member_seq` bigint NOT NULL,
  `hash` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`seq`),
  KEY `memberauction_memberseq_fk_member_seq_idx` (`member_seq`),
  CONSTRAINT `memberauction_memberseq_fk_member_seq` FOREIGN KEY (`member_seq`) REFERENCES `member` (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interest_auction`
--

LOCK TABLES `interest_auction` WRITE;
/*!40000 ALTER TABLE `interest_auction` DISABLE KEYS */;
INSERT INTO `interest_auction` VALUES (1,3,'02f69a3aa4fc360b9d08ada8df002ea3'),(2,3,'7806e4b00d8e94efb025c558ddda2977'),(3,4,'220840c73418322653e25bdc9171cce6'),(4,4,'927439293363a402e09d80d2c09f6004'),(5,4,'315a7ee0a2b9dcbd6a2e5f50b2b697eb'),(6,3,'cf34ccbe24aa024b6912da6cba2914c0'),(7,4,'0d7b3065165fba59817ab310d5d64c4c'),(8,4,'bffb2abf9585edd5540482635f187116'),(9,1,'bffb2abf9585edd5540482635f187116'),(10,4,'7806e4b00d8e94efb025c558ddda2977'),(11,4,'8b1a5e513ab4fdff21258bfc5f857697'),(12,4,'02f69a3aa4fc360b9d08ada8df002ea3');
/*!40000 ALTER TABLE `interest_auction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interest_category`
--

DROP TABLE IF EXISTS `interest_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interest_category` (
  `seq` bigint NOT NULL AUTO_INCREMENT,
  `member_seq` bigint DEFAULT NULL,
  `category_seq` bigint DEFAULT NULL,
  PRIMARY KEY (`seq`),
  KEY `membercategory_memberseq_fk_member_seq_idx` (`member_seq`),
  CONSTRAINT `membercategory_memberseq_fk_member_seq` FOREIGN KEY (`member_seq`) REFERENCES `member` (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interest_category`
--

LOCK TABLES `interest_category` WRITE;
/*!40000 ALTER TABLE `interest_category` DISABLE KEYS */;
INSERT INTO `interest_category` VALUES (1,3,2),(2,3,1),(3,3,15),(6,4,8);
/*!40000 ALTER TABLE `interest_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interest_keyword`
--

DROP TABLE IF EXISTS `interest_keyword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interest_keyword` (
  `seq` bigint NOT NULL AUTO_INCREMENT,
  `keyword_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `member_seq` bigint DEFAULT NULL,
  PRIMARY KEY (`seq`),
  KEY `interestkeyword_memberseq_fk_member_seq_idx` (`member_seq`),
  CONSTRAINT `interestkeyword_memberseq_fk_member_seq` FOREIGN KEY (`member_seq`) REFERENCES `member` (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interest_keyword`
--

LOCK TABLES `interest_keyword` WRITE;
/*!40000 ALTER TABLE `interest_keyword` DISABLE KEYS */;
INSERT INTO `interest_keyword` VALUES (1,'포켓몬빵',3),(2,'뮤츠',3),(3,'덩크로우',3),(4,'갤럭시',4),(5,'노트북',4),(6,'갤럭시',3);
/*!40000 ALTER TABLE `interest_keyword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `seq` bigint NOT NULL AUTO_INCREMENT,
  `member_id` varchar(20) NOT NULL,
  `member_name` varchar(20) NOT NULL,
  `nickname` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pwd` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `address_detail` varchar(100) DEFAULT NULL,
  `zip_code` varchar(255) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `profile_url` varchar(500) DEFAULT NULL,
  `bank_code` int DEFAULT '0',
  `account_no` varchar(50) DEFAULT NULL,
  `score` int NOT NULL DEFAULT '0',
  `notice_kakao` tinyint NOT NULL DEFAULT '0',
  `notice_email` tinyint NOT NULL DEFAULT '0',
  `status` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`seq`),
  UNIQUE KEY `member_id_UNIQUE` (`member_id`),
  UNIQUE KEY `nickname_UNIQUE` (`nickname`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  UNIQUE KEY `phone_UNIQUE` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (1,'mino308','정민호','mino308','mino@ssafy.com','$2a$10$YN80Y0i6xto.8nEilm.DsOSkfaXAjmAAAAntOk9B4YIpzA3r3OaQO','address','detail','1','01074119612','/member/517f8083-0ef2-4a38-8264-a91d6e701d4a.jpg',0,NULL,9,0,0,1),(2,'mint308','강민서','애용이','mint@ssafy.com','$2a$10$jor1ov.d9gl4.fe4Z9bYqupLiFqnRfNLgsmpRrHX7q.iKbkfeoD.y','address','detail','1','01024207504','/member/42ee572a-bb68-4729-80b6-ab9bc3dde323.jpg',0,NULL,-19,0,0,1),(3,'comet308','김혜성','comet308','syong0716@naver.com','$2a$10$s1QZ5riqE9iC4IlXfso9y.Fsv/pfD5ITR2Wpb40mBzl3qi.ndmOFK','서울 강남구 남부순환로 2803 (도곡동, 삼성래미안아파트)','101동 1701호','06277','01020097181','/member/981e3b61-be5d-4a8d-a8eb-de58467e5886.jpg',20,'1002358104657',9,0,0,1),(4,'lucas308','남은열','lucas308','lucas@ssafy.com','$2a$10$jJT5VFIbhvbOv9.wlMxAg.S.lkad0QaAw8LpuTKXydhjDxZAoHaFW','제주특별자치도 제주시 첨단로 242 (영평동)','우리집','63309','01032359083','/member/79d0d865-59fd-4dee-9b3b-d33b516986e5.png',0,NULL,10,0,0,1),(5,'eric308','김수환','eric308','eric@ssafy.com','$2a$10$Se5cvB9qAmCUI1/Bl4rML.27ctAQdfI9HOgu0ZIIe.2T40NcPeM6y','서울 관악구 관악로15길 23-12 (봉천동, 서울대역해담채)','1103호','08787','01025702489','/member/12eae5f6-b242-4208-b0a5-ee69a6d349de.jpg',88,'110369341058',13,0,0,1),(6,'galaxy98','길럭시','갤럭시조아','galaxy@ssafy.com','$2a$10$by5w8HEPgDRawoowYPkLpuwXhP07UqE4YyqVIs/u0keOKL5P.J8La','경기 성남시 분당구 판교역로 235 (삼평동, 에이치스퀘어 엔동)','303호','13494','01020097180','/member/basic5.png',3,'01050236903',3,0,0,1),(9,'galaxy308','김삼성','갤럭시맨','galaxy308@ssafy.com','$2a$10$uvaz874hVFlml6P1y/8So.m/Iny3swMCbH3qP95yZkYIxFp11iKDC','address','detail','1','01012345678','/member/7b551fbf-29cf-49f4-9694-bad92e555124.jpg',0,NULL,-10,0,0,1);
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parcel_company`
--

DROP TABLE IF EXISTS `parcel_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `parcel_company` (
  `parcel_company_code` varchar(10) NOT NULL,
  `parcel_company_name` varchar(30) NOT NULL,
  PRIMARY KEY (`parcel_company_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parcel_company`
--

LOCK TABLES `parcel_company` WRITE;
/*!40000 ALTER TABLE `parcel_company` DISABLE KEYS */;
INSERT INTO `parcel_company` VALUES ('01','우체국택배'),('04','CJ대한통운'),('05','한진택배'),('06','로젠택배'),('08','롯데택배'),('101','한샘서비스원 택배'),('103','NDEX KOREA'),('104','도도플렉스'),('107','LG전자(판토스)'),('11','일양로지스'),('110','부릉'),('112','1004홈'),('113','썬더히어로'),('116','(주)팀프레시'),('118','롯데칠성'),('119','핑퐁'),('120','발렉스 특수물류'),('123','엔티엘피스'),('125','GTS로지스'),('127','로지스팟'),('129','홈픽 오늘도착'),('130','UFO로지스'),('131','딜리래빗'),('132','지오피'),('134','에이치케이홀딩스'),('135','HTNS'),('136','케이제이티'),('137','더바오'),('138','라스트마일'),('139','오늘회 러쉬'),('142','탱고앤고'),('143','투데이'),('16','한의사랑택배'),('17','천일택배'),('18','건영택배'),('20','한덱스'),('22','대신택배'),('23','경동택배'),('24','GS Postbox 택배'),('32','합동택배'),('40','굿투럭'),('43','애니트랙'),('44','SLX택배'),('45','우리택배'),('46','CU 편의점택배'),('47','우리한방택배'),('53','농협택배'),('54','홈픽택배'),('71','IK물류'),('72','성훈물류'),('74','용마로지스'),('75','원더스퀵'),('79','로지스밸리택배'),('82','컬리로지스'),('85','풀앳홈'),('86','삼성전자물류'),('88','큐런택배'),('89','두발히어로'),('90','위니아딤채'),('92','지니고 당일배송'),('94','오늘의픽업'),('96','로지스밸리');
/*!40000 ALTER TABLE `parcel_company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `seq` bigint NOT NULL AUTO_INCREMENT,
  `auction_seq` bigint NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `start_price` int NOT NULL DEFAULT '0',
  `final_price` int DEFAULT NULL,
  `status` int DEFAULT '0',
  PRIMARY KEY (`seq`),
  KEY `product_auctionseq_fk_auction_seq_idx` (`auction_seq`),
  CONSTRAINT `product_auctionseq_fk_auction_seq` FOREIGN KEY (`auction_seq`) REFERENCES `auction` (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (2,1,'크림색 일자바지',7000,7000,0),(3,1,'찢어진 청바지',5000,5000,0),(5,3,'스투시반팔흰색',30000,30000,0),(6,3,'스투시반팔검정',30000,30000,0),(7,4,'나이키 바람막이',60000,60000,0),(8,5,'맥 립스틱 코랄색',10000,10000,0),(9,5,'맥 루비우',10000,10000,0),(10,6,'asus노트북',300000,420000,3),(11,7,'노트북파우치',10000,15000,3),(12,8,'가디건',5000,5000,0),(13,9,'냉정과열정사이',20000,22000,3),(14,10,'프라이탁 가방',100000,113000,3),(15,11,'에어팟 프로',100000,100000,0),(16,12,'키보드',50000,70000,3),(17,13,'피아노',300000,350000,1),(18,14,'카메라',30000,35000,3),(19,15,'스누피 컵',5000,7000,1),(20,16,'버티컬마우스',30000,35000,3),(21,17,'시계',20000,20000,0),(22,18,'닌텐도스위치',200000,200000,0),(23,19,'컴퓨터아키텍처',5000,5000,0),(24,19,'정보교과교육론',5000,5000,0),(25,19,'컴퓨터네트워킹',5000,5000,0),(26,20,'액션토끼 인형',3000,5000,3),(27,20,'액션토끼 인형 미니',2000,2000,0),(28,20,'고라파덕 인형',3000,3000,0),(29,20,'파이리 인형',3000,3000,0),(30,20,'위베어베어스 인형',5000,5000,0),(31,20,'돼지 인형',3000,3000,0),(32,20,'코알라 인형',2000,2000,0),(33,21,'기본춘식이',10000,15000,2),(34,21,'잠옷춘식이',10000,15000,2),(35,22,'브라운가습기',50000,63000,3),(36,23,'마우스패드',3000,5000,3),(39,24,'눈마사지기',20000,45000,3),(40,26,'별의 커비',30000,36000,3),(41,28,'갤럭시탭S8',350000,350000,0),(42,29,'갤럭시Z플립2',300000,300000,0),(43,31,'갤럭시 버즈',60000,60000,0),(44,32,'갤럭시21',200000,200000,0),(45,32,'갤럭시22',350000,350000,0),(46,32,'갤럭시Z플립',400000,400000,0),(47,33,'갤럭시탭 S7',250000,250000,0),(53,36,'곰인형',5000,5000,0),(54,37,'공기청정기',150000,150000,0),(55,38,'향수',10000,15000,3),(56,39,'아르세우스',30000,30000,1),(57,40,'푸시업바',10000,12000,1),(58,41,'애옹이파우치',5000,10000,1),(59,42,'이솝핸드크림',10000,21000,2),(60,43,'양키캔틀체리',15000,20000,2),(61,44,'손목시계',100000,190000,2);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_delivery`
--

DROP TABLE IF EXISTS `product_delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_delivery` (
  `seq` bigint NOT NULL AUTO_INCREMENT,
  `product_seq` bigint NOT NULL,
  `name` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `address_detail` varchar(255) DEFAULT NULL,
  `zip_code` varchar(255) DEFAULT NULL,
  `remit_name` varchar(20) DEFAULT NULL,
  `remit_status` tinyint DEFAULT '0',
  `parcel_company_code` varchar(20) DEFAULT '0',
  `tracking_no` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`seq`),
  KEY `productdelivery_productseq_fk_product_seq_idx` (`product_seq`),
  CONSTRAINT `productdelivery_productseq_fk_product_seq` FOREIGN KEY (`product_seq`) REFERENCES `product` (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_delivery`
--

LOCK TABLES `product_delivery` WRITE;
/*!40000 ALTER TABLE `product_delivery` DISABLE KEYS */;
INSERT INTO `product_delivery` VALUES (1,13,'남은열','01032359083','제주특별자치도 제주시 첨단로 242 (영평동)','우리집',NULL,'',0,'04','564764894094'),(2,14,'남은열','01032359083','제주특별자치도 제주시 첨단로 242 (영평동)','우리집',NULL,'',0,'04','564764894094'),(3,10,'남은열','01032359083','제주특별자치도 제주시 첨단로 242 (영평동)','우리집',NULL,'남은열',0,'04','564764894094'),(4,11,'남은열','01032359083','제주특별자치도 제주시 첨단로 242 (영평동)','우리집',NULL,'남은열',0,'04','564764894094'),(5,26,'남은열','01032359083','제주특별자치도 제주시 첨단로 242 (영평동)','우리집',NULL,'정민호',0,'04','564764894094'),(6,57,'남은열','01032359083','제주특별자치도 제주시 첨단로 242 (영평동)','우리집',NULL,'남은열',0,NULL,NULL),(7,58,'남은열','01032359083','제주특별자치도 제주시 첨단로 242 (영평동)','우리집',NULL,'남은열',0,NULL,NULL),(8,59,'남은열','01032359083','제주특별자치도 제주시 첨단로 242 (영평동)','우리집',NULL,'남은열',0,NULL,NULL),(9,60,'남은열','01032359083','제주특별자치도 제주시 첨단로 242 (영평동)','우리집',NULL,'남은열',0,NULL,NULL),(10,61,'남은열','01032359083','제주특별자치도 제주시 첨단로 242 (영평동)','우리집',NULL,'남은열',0,NULL,NULL),(11,18,'정민호','01074119612','address','detail',NULL,'정민호',0,'04','564764894094'),(12,36,'정민호','01074119612','address','detail',NULL,'정민호',0,'04','564764894094'),(13,39,'정민호','01074119612','address','detail',NULL,'정민호',0,'04','564764894094'),(14,16,'강민서','01024207504','address','detail',NULL,'강민서',0,'04','564764894094'),(15,17,'김수환','01025702489','서울 관악구 관악로15길 23-12 (봉천동, 서울대역해담채)','1103호',NULL,'김수환',0,NULL,NULL),(16,19,'김수환','01025702489','서울 관악구 관악로15길 23-12 (봉천동, 서울대역해담채)','1103호',NULL,'김수환',0,NULL,NULL),(17,20,'김수환','01025702489','서울 관악구 관악로15길 23-12 (봉천동, 서울대역해담채)','1103호',NULL,'김수환',0,'04','564764894094'),(18,33,'김혜성','01020097181','서울 강남구 남부순환로 2803 (도곡동, 삼성래미안아파트)','101동 1701호',NULL,'김혜성',0,NULL,NULL),(19,34,'김혜성','01020097181','서울 강남구 남부순환로 2803 (도곡동, 삼성래미안아파트)','101동 1701호',NULL,'김혜성',0,NULL,NULL),(20,35,'김혜성','01020097181','서울 강남구 남부순환로 2803 (도곡동, 삼성래미안아파트)','101동 1701호',NULL,'',0,'04','564764894094'),(21,40,'강민서','01024207504','address','detail',NULL,'강민서',0,'04','564764894094'),(22,55,'강민서','01024207504','address','detail',NULL,'강민서',0,'04','564764894094');
/*!40000 ALTER TABLE `product_delivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refresh_token`
--

DROP TABLE IF EXISTS `refresh_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `refresh_token` (
  `seq` bigint NOT NULL AUTO_INCREMENT,
  `refresh_token` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `member_seq` bigint DEFAULT NULL,
  PRIMARY KEY (`seq`),
  KEY `FKrfd9y6noq2cxom5kkq0hoqk9t` (`member_seq`),
  CONSTRAINT `FKrfd9y6noq2cxom5kkq0hoqk9t` FOREIGN KEY (`member_seq`) REFERENCES `member` (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refresh_token`
--

LOCK TABLES `refresh_token` WRITE;
/*!40000 ALTER TABLE `refresh_token` DISABLE KEYS */;
INSERT INTO `refresh_token` VALUES (1,'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJtaW5vMzA4IiwiaXNzIjoic3NhZnkuY29tIiwiZXhwIjoxNjYxNDYyNjUzLCJ1c2VySWQiOiJtaW5vMzA4IiwiaWF0IjoxNjYwODU3ODUzfQ.mz0zoXrkkCGODqGWG5OPpT1IbPzqqqPH1TI78cFNnj8EXzPZ47VyAepAymSbKQzzP44e6U3vSgzPfocYh0o_6g',1),(2,'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJtaW50MzA4IiwiaXNzIjoic3NhZnkuY29tIiwiZXhwIjoxNjYxNDYyNjk2LCJ1c2VySWQiOiJtaW50MzA4IiwiaWF0IjoxNjYwODU3ODk2fQ.7imfD-yMzIqpgYt75XEtIhr0uMCW7e2OG0gXvMba-kSM8UYda6SMBd3FMCO8t0OgifeBNe6DHavBlWbe9jpnAw',2),(3,'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJjb21ldDMwOCIsImlzcyI6InNzYWZ5LmNvbSIsImV4cCI6MTY2MTQ2MjU5NCwidXNlcklkIjoiY29tZXQzMDgiLCJpYXQiOjE2NjA4NTc3OTR9.gp8M9vDAXV70cUA7Up_gcmKFWHkaPaVnFpUo13Nq6rzFOkIpnSkj5FED-m2Z8m2P3PMA7QwHQLL_GY4dyiGmWA',3),(4,'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJsdWNhczMwOCIsImlzcyI6InNzYWZ5LmNvbSIsImV4cCI6MTY2MTQ2MzIxNCwidXNlcklkIjoibHVjYXMzMDgiLCJpYXQiOjE2NjA4NTg0MTR9.3Pffok6KwapbY2uBobS00rCLdfzqEGhWLtWaS-zKOnS-Gb1eNj0qWKuRpyYnpT7IENRIxOv2lNY60WimooWaBQ',4),(5,'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJlcmljMzA4IiwiaXNzIjoic3NhZnkuY29tIiwiZXhwIjoxNjYxNDYyOTkyLCJ1c2VySWQiOiJlcmljMzA4IiwiaWF0IjoxNjYwODU4MTkyfQ.OKq-U6A0reL0MvA-8zC6zzkJD5Vnt6vMG82-Rnd_ZqwMDoMVTXtW9oUbzeT7KCvSyW8SUB9oCu9r198saCA3xg',5),(6,'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJnYWxheHk5OCIsImlzcyI6InNzYWZ5LmNvbSIsImV4cCI6MTY2MTQ0MzU0NSwidXNlcklkIjoiZ2FsYXh5OTgiLCJpYXQiOjE2NjA4Mzg3NDV9.vaqRMSJOMWQloryYgzPYsorQ7mX2LnbPix6uegjF38-F37i1PsAxp9bW02g-T-AwaPDB1BYHHi0kHxHIJbfkwQ',6),(7,'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJnYWxheHkzMDgiLCJpc3MiOiJzc2FmeS5jb20iLCJleHAiOjE2NjE0NTQ3OTAsInVzZXJJZCI6ImdhbGF4eTMwOCIsImlhdCI6MTY2MDg0OTk5MH0.8Zr4s_qQDMI6GCXSXroSNXOved9DIVhFIgabYLZ03RjUNgIiP2MxetSF__P7XpW_1uoOizm6gAxSKhe65T3hOw',9);
/*!40000 ALTER TABLE `refresh_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review` (
  `seq` bigint NOT NULL AUTO_INCREMENT,
  `writer_seq` bigint NOT NULL,
  `receiver_seq` bigint NOT NULL,
  `content` varchar(500) NOT NULL,
  `score` int NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`seq`),
  KEY `review_receiverseq_fk_member_seq_idx` (`receiver_seq`),
  CONSTRAINT `review_receiverseq_fk_member_seq` FOREIGN KEY (`receiver_seq`) REFERENCES `member` (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES (1,4,5,'잘 쓸게요 너무 갖고싶었던거에요~!!',5,'2022-08-07 16:11:48'),(3,1,5,'좋은 거래 감사합니다 ㅎㅎ 많이파세요!',5,'2022-08-12 13:52:48'),(4,2,5,'덕분에 싸게 잘 샀습니다! 이분 짱인듯',5,'2022-08-14 21:02:11'),(5,3,5,'배송이 조금 늦었지만 그래도 물건은 좋았어요!',4,'2022-08-17 12:11:43'),(6,6,5,'싸다 싸 !!',4,'2022-08-10 14:20:43'),(7,1,4,'항상 좋은 물건 싸게 주셔서 감사합니다!',5,'2022-08-17 14:20:43'),(8,2,4,'배송 엄청 빨리 해주시구 물건도 깨끗해요!',5,'2022-08-15 13:56:21'),(9,3,4,'빨리 경매 더열어주세요~~~',5,'2022-08-14 19:11:21'),(10,5,4,'경매 진행을 너무너무 잘하세요!',5,'2022-08-12 08:03:17'),(12,4,3,'귀여워요!!',5,'2022-08-19 06:29:30');
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  6:34:50
